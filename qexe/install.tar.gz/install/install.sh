#!/bin/bash

# INSTALLER CONFIGURATION
JRE_LOCATION="./jre"
JRE_INSTALLER="jre-8u121-linux-i586.rpm"

# Versión de migración de elasticsearch
ELS_VERSION="6.2.4"
ELS_DIR_NAME="elasticsearch-$ELS_VERSION"
ELS_INSTALLER="elasticsearch-$ELS_VERSION.zip"

function installJRE()
{
    echo ""
    echo "JAVA RUNTIME"
    echo ""

    echo "Installing JRE: $JRE_INSTALLER..."
    rpm -i $JRE_LOCATION/$JRE_INSTALLER

    echo ""
    echo "JAVA RUNTIME DONE"
}

function installElastic()
{
    echo ""
    echo "ELASTICSEARCH"
    echo ""

    echo "Uncompressing ElasticSearch ($ELS_INSTALLER)..."
    unzip $ELS_INSTALLER

    echo "ELASTICSEARCH DONE"
    echo ""
}

function main()
{
    installJRE
    installElastic

    return 0
}

#calling main function
main
